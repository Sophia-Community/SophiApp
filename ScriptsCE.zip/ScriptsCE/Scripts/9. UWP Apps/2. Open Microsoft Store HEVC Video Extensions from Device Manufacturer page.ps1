﻿<#
Open Microsoft Store "HEVC Video Extensions from Device Manufacturer" page
The extension can be installed without Microsoft account
"Movies & TV" app required

Открыть страницу "Расширения для видео HEVC от производителя устройства" в Microsoft Store
Расширение может быть установлено без учетной записи Microsoft
Для работы необходимо приложение "Кино и ТВ"
#>
if (Get-AppxPackage -Name Microsoft.ZuneVideo)
{
	Start-Process -FilePath ms-windows-store://pdp/?ProductId=9n4wgh0z6vhq
}