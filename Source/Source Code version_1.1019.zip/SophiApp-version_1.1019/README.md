![Build and Release](https://github.com/farag2/SophiApp/workflows/Build%20and%20Release/badge.svg)
# Deus vult!
