﻿# Turn off Xbox Game Bar tips
# Отключить советы Xbox Game Bar
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Turn off Xbox Game Bar tips
# Отключить советы Xbox Game Bar
if ($Off.IsPresent)
{
	if ((Get-AppxPackage -Name Microsoft.XboxGamingOverlay) -or (Get-AppxPackage -Name Microsoft.GamingApp))
	{
		New-ItemProperty -Path HKCU:\Software\Microsoft\GameBar -Name ShowStartupPanel -PropertyType DWord -Value 0 -Force
	}
}

# Turn on Xbox Game Bar tips
# Включить советы Xbox Game Bar
if ($On.IsPresent)
{
	if ((Get-AppxPackage -Name Microsoft.XboxGamingOverlay) -or (Get-AppxPackage -Name Microsoft.GamingApp))
	{
		New-ItemProperty -Path HKCU:\Software\Microsoft\GameBar -Name ShowStartupPanel -PropertyType DWord -Value 1 -Force
	}
}
