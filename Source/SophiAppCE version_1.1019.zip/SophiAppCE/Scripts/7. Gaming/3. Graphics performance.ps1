﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Set "High performance" in graphics performance preference for apps
# Установить параметры производительности графики для отдельных приложений на "Высокая производительность"
if ($On.IsPresent)
{
	if (Get-CimInstance -ClassName Win32_VideoController | Where-Object -FilterScript {$_.AdapterDACType -ne "Internal" -and $null -ne $_.AdapterDACType})
	{
		if ($RU)
		{
			$Title = "Настройка производительности графики"
			$Message = "Установить для любого приложения по вашему выбору настройки производительности графики на `"Высокая производительность`"?"
			$Options = "&Создать", "&Пропустить"
		}
		else
		{
			$Title = "Graphics performance preference"
			$Message = "Would you like to set the graphics performance setting of an app of your choice to `"High performance`"?"
			$Options = "&Add", "&Skip"
		}
		$DefaultChoice = 1

		do
		{
			$Result = $Host.UI.PromptForChoice($Title, $Message, $Options, $DefaultChoice)
			switch ($Result)
			{
				"0"
				{
					Add-Type -AssemblyName System.Windows.Forms
					$OpenFileDialog = New-Object -TypeName System.Windows.Forms.OpenFileDialog
					if ($RU)
					{
						$OpenFileDialog.Filter = "*.exe|*.exe|Все файлы (*.*)|*.*"
					}
					else
					{
						$OpenFileDialog.Filter = "*.exe|*.exe|All Files (*.*)|*.*"
					}
					$OpenFileDialog.InitialDirectory = "${env:ProgramFiles(x86)}"
					$OpenFileDialog.Multiselect = $false
					# Focus on open file dialog
					# Перевести фокус на диалог открытия файла
					$tmp = New-Object -TypeName System.Windows.Forms.Form -Property @{TopMost = $true}
					$OpenFileDialog.ShowDialog($tmp)
					if ($OpenFileDialog.FileName)
					{
						if (-not (Test-Path -Path HKCU:\Software\Microsoft\DirectX\UserGpuPreferences))
						{
							New-Item -Path HKCU:\Software\Microsoft\DirectX\UserGpuPreferences -Force
						}
						New-ItemProperty -Path HKCU:\Software\Microsoft\DirectX\UserGpuPreferences -Name $OpenFileDialog.FileName -PropertyType String -Value "GpuPreference=2;" -Force
					}
				}
				"1"
				{
					if ($RU)
					{
						Write-Verbose -Message "Пропущено" -Verbose
					}
					else
					{
						Write-Verbose -Message "Skipped" -Verbose
					}
				}
			}
		}
		until ($Result -eq 1)
	}
}