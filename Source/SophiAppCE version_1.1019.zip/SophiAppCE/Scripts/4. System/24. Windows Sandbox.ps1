﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Enable Windows Sandbox
# Включить Windows Sandbox
if ($On.IsPresent)
{
	if (Get-WindowsEdition -Online | Where-Object -FilterScript {$_.Edition -eq "Professional" -or $_.Edition -like "Enterprise*"})
	{
		# Checking whether x86 virtualization is enabled in the firmware
		# Проверка: включена ли в настройках UEFI аппаратная виртуализация x86
		if ((Get-CimInstance -ClassName CIM_Processor).VirtualizationFirmwareEnabled -eq $true)
		{
			Enable-WindowsOptionalFeature -FeatureName Containers-DisposableClientVM -All -Online -NoRestart
		}
		else
		{
			try
			{
				# Determining whether Hyper-V is enabled
				# Проверка: включен ли Hyper-V
				if ((Get-CimInstance -ClassName CIM_ComputerSystem).HypervisorPresent -eq $true)
				{
					Enable-WindowsOptionalFeature -FeatureName Containers-DisposableClientVM -All -Online -NoRestart
				}
			}
			catch [Exception]
			{
				if ($RU)
				{
					Write-Error -Message "Включите в BIOS виртуализацию" -ErrorAction SilentlyContinue
				}
				else
				{
					Write-Error -Message "Enable Virtualization in BIOS" -ErrorAction SilentlyContinue
				}
			}
		}
	}
}

# Disable Windows Sandbox
# Выключить Windows Sandbox
if ($Off.IsPresent)
{
	if (Get-WindowsEdition -Online | Where-Object -FilterScript {$_.Edition -eq "Professional" -or $_.Edition -like "Enterprise*"})
	{
		# Checking whether x86 virtualization is enabled in the firmware
		# Проверка: включена ли в настройках UEFI аппаратная виртуализация x86
		if ((Get-CimInstance -ClassName CIM_Processor).VirtualizationFirmwareEnabled -eq $true)
		{
			Disable-WindowsOptionalFeature -FeatureName Containers-DisposableClientVM -All -Online -NoRestart
		}
		else
		{
			try
			{
				# Determining whether Hyper-V is enabled
				# Проверка: включен ли Hyper-V
				if ((Get-CimInstance -ClassName CIM_ComputerSystem).HypervisorPresent -eq $true)
				{
					Disable-WindowsOptionalFeature -FeatureName Containers-DisposableClientVM -All -Online -NoRestart
				}
			}
			catch [Exception]
			{
				if ($RU)
				{
					Write-Error -Message "Включите в BIOS виртуализацию" -ErrorAction SilentlyContinue
				}
				else
				{
					Write-Error -Message "Enable Virtualization in BIOS" -ErrorAction SilentlyContinue
				}
			}
		}
	}
}
