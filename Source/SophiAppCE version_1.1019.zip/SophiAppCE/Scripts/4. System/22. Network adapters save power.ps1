﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Allow the computer to turn off all the network adapters to save power
# Разрешить отключение всех сетевых адаптеров для экономии энергии
if ($On.IsPresent)
{
	$Adapters = Get-NetAdapter -Physical | Get-NetAdapterPowerManagement | Where-Object -FilterScript {$_.AllowComputerToTurnOffDevice -ne "Unsupported"}
	foreach ($Adapter in $Adapters)
	{
		$Adapter.AllowComputerToTurnOffDevice = "Enabled"
		$Adapter | Set-NetAdapterPowerManagement
	}
}

# Do not allow the computer (if device is not a laptop) to turn off all the network adapters to save power
# Запретить отключение всех сетевых адаптеров для экономии энергии (если устройство не является ноутбуком)
if ($Off.IsPresent)
{
	if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -ne 2)
	{
		$Adapters = Get-NetAdapter -Physical | Get-NetAdapterPowerManagement | Where-Object -FilterScript {$_.AllowComputerToTurnOffDevice -ne "Unsupported"}
		foreach ($Adapter in $Adapters)
		{
			$Adapter.AllowComputerToTurnOffDevice = "Disabled"
			$Adapter | Set-NetAdapterPowerManagement
		}
	}
}
