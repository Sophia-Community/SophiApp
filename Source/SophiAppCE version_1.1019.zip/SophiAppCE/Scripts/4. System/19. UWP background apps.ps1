﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Let UWP apps run in the background (current user only)
# Разрешить UWP-приложениям работать в фоновом режиме (только для текущего пользователя)
if ($On.IsPresent)
{
	Get-ChildItem -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications | ForEach-Object -Process {
		Remove-ItemProperty -Path $_.PsPath -Name * -Force
	}
}

# Do not let UWP apps run in the background, except the followings... (current user only)
# Не разрешать UWP-приложениям работать в фоновом режиме, кроме следующих... (только для текущего пользователя)
if ($Off.IsPresent)
{
	Get-ChildItem -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications | ForEach-Object -Process {
		Remove-ItemProperty -Path $_.PsPath -Name * -Force
	}

	$ExcludedBackgroundApps = @(
		# Lock screen app
		# Экран блокировки
		"Microsoft.LockApp*",
		
		# Content Delivery Manager (delivers Windows Spotlight wallpapers to the lock screen)
		# Content Delivery Manager (доставляет обои для Windows Spotlight на экран блокировки)
		"Microsoft.Windows.ContentDeliveryManager*",

		# Cortana
		"Microsoft.Windows.Cortana*",

		# Windows Search
		"Microsoft.Windows.Search*",

		# Windows Security
		# Безопасность Windows
		"Microsoft.Windows.SecHealthUI*",

		# Windows Shell Experience (Action center, snipping support, toast notification, touch screen keyboard)
		# Windows Shell Experience (Центр уведомлений, приложение "Ножницы", тостовые уведомления, сенсорная клавиатура)
		"Microsoft.Windows.ShellExperienceHost*",

		# The Start menu
		# Меню "Пуск"
		"Microsoft.Windows.StartMenuExperienceHost*",

		# Microsoft Store
		"Microsoft.WindowsStore*"
	)
	$OFS = "|"
	Get-ChildItem -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications | Where-Object -FilterScript {$_.PSChildName -cnotmatch $ExcludedBackgroundApps} | ForEach-Object -Process {
		New-ItemProperty -Path $_.PsPath -Name Disabled -PropertyType DWord -Value 1 -Force
		New-ItemProperty -Path $_.PsPath -Name DisabledByUser -PropertyType DWord -Value 1 -Force
	}
	$OFS = " "

	# Open "Background apps" page
	# Открыть раздел "Фоновые приложения"
	Start-Process -FilePath ms-settings:privacy-backgroundapps
}
