﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Set the power management scheme on "High performance" if device is a desktop
# Установить схему управления питанием на "Высокая производительность", если устройство является стационарным ПК
if ($On.IsPresent)
{
	if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -eq 1)
	{
		# High performance
		# Высокая производительность
		POWERCFG /SETACTIVE SCHEME_MIN
	}
}

# Set the power management scheme on "Balanced" (default)
# Установить схему управления питанием на "Сбалансированная" (значение по умолчанию)
if ($Off.IsPresent)
{
	# Balanced
	# Сбалансированная
	POWERCFG /SETACTIVE SCHEME_BALANCED
}
