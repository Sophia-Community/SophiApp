﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Install the Windows Subsystem for Linux (WSL)
# Установить подсистему Windows для Linux (WSL)
# https://github.com/farag2/Windows-10-Setup-Script/issues/43
# https://github.com/microsoft/WSL/issues/5437
if ($On.IsPresent)
{
	$WSLFeatures = @(
		# Enable the Windows Subsystem for Linux
		# Включить подсистему Windows для Linux
		"Microsoft-Windows-Subsystem-Linux",

		# Enable Virtual Machine Platform
		# Включить поддержку платформы для виртуальных машин
		"VirtualMachinePlatform"
	)
	Enable-WindowsOptionalFeature -Online -FeatureName $WSLFeatures -NoRestart

	# Downloading the Linux kernel update package
	# Скачиваем пакет обновления ядра Linux
	try
	{
		[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
		if ((Invoke-WebRequest -Uri https://www.google.com -UseBasicParsing -DisableKeepAlive -Method Head).StatusDescription)
		{
			$Parameters = @{
				Uri = "https://wslstorestorage.blob.core.windows.net/wslblob/wsl_update_x64.msi"
				OutFile = "$PSScriptRoot\wsl_update_x64.msi"
				Verbose = [switch]::Present
			}
			Invoke-WebRequest @Parameters

			Start-Process -FilePath $PSScriptRoot\wsl_update_x64.msi -ArgumentList "/passive" -Wait
			Remove-Item -Path $PSScriptRoot\wsl_update_x64.msi -Force
		}
	}
	catch
	{
		if ($Error.Exception.Status -eq "NameResolutionFailure")
		{
			if ($RU)
			{
				Write-Warning -Message "Отсутствует интернет-соединение" -ErrorAction SilentlyContinue
			}
			else
			{
				Write-Warning -Message "No Internet connection" -ErrorAction SilentlyContinue
			}
		}
	}
}

# Uninstall the Windows Subsystem for Linux (WSL2)
# Удалить подсистему Windows для Linux (WSL2)
if ($Off.IsPresent)
{
	$WSLFeatures = @(
		# Enable the Windows Subsystem for Linux
		# Включить подсистему Windows для Linux
		"Microsoft-Windows-Subsystem-Linux",

		# Enable Virtual Machine Platform
		# Включить поддержку платформы для виртуальных машин
		"VirtualMachinePlatform"
	)

	Disable-WindowsOptionalFeature -Online -FeatureName $WSLFeatures -NoRestart
	Remove-Item -Path "$env:HOMEPATH\.wslconfig" -Force -ErrorAction Ignore
}
