﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Disable hibernation if the device is not a laptop
# Отключить режим гибернации, если устройство не является ноутбуком
if ($Off.IsPresent)
{
	if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -ne 2)
	{
		POWERCFG /HIBERNATE OFF
	}
}

# Turn on hibernate
# Включить режим гибернации
if ($On.IsPresent)
{
	POWERCFG /HIBERNATE ON
}
