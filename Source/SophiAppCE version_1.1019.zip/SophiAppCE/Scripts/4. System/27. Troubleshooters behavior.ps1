﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Run troubleshooters automatically, then notify
# Автоматически запускать средства устранения неполадок, а затем уведомлять
if ($On.IsPresent)
{
	if (-not (Test-Path -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation))
	{
		New-Item -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation -Force
	}
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation -Name UserPreference -PropertyType DWord -Value 3 -Force

	# Set the OS level of diagnostic data gathering to full
	# Установить уровень сбора диагностических сведений ОС на максимальный
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 3 -Force
}

# Ask me before running troubleshooters (default value)
# Спрашивать перед запуском средств устранения неполадок (значение по умолчанию)
if ($Off.IsPresent)
{
	if (-not (Test-Path -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation))
	{
		New-Item -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation -Force
	}
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\WindowsMitigation -Name UserPreference -PropertyType DWord -Value 2 -Force

	# Set the OS level of diagnostic data gathering to full
	# Установить уровень сбора диагностических сведений ОС на максимальный
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 3 -Force
}
