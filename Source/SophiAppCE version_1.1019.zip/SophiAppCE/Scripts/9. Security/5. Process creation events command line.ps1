﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Do not include command line in process creation events
# Не включать командную строку в событиях создания процесса
if ($Off.IsPresent)
{
	Remove-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit -Name ProcessCreationIncludeCmdLine_Enabled -Force
}

<#
Include command line in process creation events
In order this feature to work events auditing must be enabled

Включать командную строку в событиях создания процесса
Необходимо включить аудит событий, чтобы работала данная опция
#>
if ($On.IsPresent)
{
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System\Audit -Name ProcessCreationIncludeCmdLine_Enabled -PropertyType DWord -Value 1 -Force
}