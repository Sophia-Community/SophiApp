﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Remove "Process Creation" Event Viewer Custom View
# Удалить настаиваемое представление "Создание процесса" в Просмотре событий
if ($Off.IsPresent)
{
	Remove-Item -Path "$env:ProgramData\Microsoft\Event Viewer\Views\ProcessCreation.xml" -Force
}

<#
Create "Process Creation" Event Viewer Custom View
In order this feature to work events auditing and command line in process creation events must be enabled

Создать настаиваемое представление "Создание процесса" в Просмотре событий
Необходимо включить аудит событий и командной строки в событиях создания процесса, чтобы работала данная опция
#>
if ($On.IsPresent)
{
	$XML = @"
<ViewerConfig>
	<QueryConfig>
		<QueryParams>
			<UserQuery />
		</QueryParams>
		<QueryNode>
			<Name>Process Creation</Name>
			<Description>Process Creation and Command-line Auditing Events</Description>
			<QueryList>
				<Query Id="0" Path="Security">
					<Select Path="Security">*[System[(EventID=4688)]]</Select>
				</Query>
			</QueryList>
		</QueryNode>
	</QueryConfig>
</ViewerConfig>
"@
	if (-not (Test-Path -Path "$env:ProgramData\Microsoft\Event Viewer\Views"))
	{
		New-Item -Path "$env:ProgramData\Microsoft\Event Viewer\Views" -ItemType Directory -Force
	}
	$ProcessCreationFilePath = "$env:ProgramData\Microsoft\Event Viewer\Views\ProcessCreation.xml"
	# Saving ProcessCreation.xml in UTF-8 encoding
	# Сохраняем ProcessCreation.xml в кодировке UTF-8
	Set-Content -Path $ProcessCreationFilePath -Value (New-Object System.Text.UTF8Encoding).GetBytes($XML) -Encoding Byte -Force

	if ($RU)
	{
		[xml]$XML = Get-Content -Path $ProcessCreationFilePath
		$XML.ViewerConfig.QueryConfig.QueryNode.Name = "Создание процесса"
		$XML.ViewerConfig.QueryConfig.QueryNode.Description = "События содания нового процесса и аудит командной строки"
		$xml.Save("$env:ProgramData\Microsoft\Event Viewer\Views\ProcessCreation.xml")
	}
}
