﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Turn off detection for potentially unwanted applications and block them
# Выключить обнаружение потенциально нежелательных приложений и блокировать их
if ($Off.IsPresent)
{
	Set-MpPreference -PUAProtection Disabled
}

# Turn on detection for potentially unwanted applications and block them
# Включить обнаружение потенциально нежелательных приложений и блокировать их
if ($On.IsPresent)
{
	Set-MpPreference -PUAProtection Enabled
}
