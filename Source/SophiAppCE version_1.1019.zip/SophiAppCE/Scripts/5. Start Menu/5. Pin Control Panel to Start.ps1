﻿param
(
	[Parameter()]
	[switch]
	$On
)

# Pin "Control Panel" to Start
# Закрепить ярлык "Панели управления" и на начальном экране
if ($On.IsPresent)
{
	if (Test-Path -Path $PSScriptRoot\syspin.exe)
	{
		$syspin = $true
	}
	else
	{
		try
		{
			# Downloading syspin.exe
			# Скачиваем syspin.exe
			# http://www.technosys.net/products/utils/pintotaskbar
			# SHA256: 6967E7A3C2251812DD6B3FA0265FB7B61AADC568F562A98C50C345908C6E827
			[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
			if ((Invoke-WebRequest -Uri https://www.google.com -UseBasicParsing -DisableKeepAlive -Method Head).StatusDescription)
			{
				$Parameters = @{
					Uri = "https://github.com/farag2/Windows-10-Setup-Script/raw/master/Start%20menu%20pinning/syspin.exe"
					OutFile = "$PSScriptRoot\syspin.exe"
					Verbose = [switch]::Present
				}
				Invoke-WebRequest @Parameters
				$syspin = $true
			}
		}
		catch
		{
			if ($Error.Exception.Status -eq "NameResolutionFailure")
			{
				if ($RU)
				{
					Write-Warning -Message "Отсутствует интернет-соединение" -ErrorAction SilentlyContinue
				}
				else
				{
					Write-Warning -Message "No Internet connection" -ErrorAction SilentlyContinue
				}
			}
		}
	}

	if ($syspin -eq $true)
	{
		$Items = (New-Object -ComObject Shell.Application).NameSpace("shell:::{4234d49b-0245-4df3-b780-3893943456e1}").Items()
		$ControlPanelLocalizedName = ($Items | Where-Object -FilterScript {$_.Path -eq "Microsoft.Windows.ControlPanel"}).Name
		if ($RU)
		{
			Write-Verbose -Message "Ярлык `"$ControlPanelLocalizedName`" закрепляется на начальном экране" -Verbose
		}
		else
		{
			Write-Verbose -Message "`"$ControlPanelLocalizedName`" shortcut is being pinned to Start" -Verbose
		}

		# Check whether the Control Panel shortcut was ever pinned
		# Проверка: закреплялся ли когда-нибудь ярлык панели управления
		if (Test-Path -Path "$env:APPDATA\Microsoft\Windows\Start menu\Programs\$ControlPanelLocalizedName.lnk")
		{
			$Arguments = @"
	"$env:APPDATA\Microsoft\Windows\Start menu\Programs\$ControlPanelLocalizedName.lnk" "51201"
"@
			Start-Process -FilePath $PSScriptRoot\syspin.exe -WindowStyle Hidden -ArgumentList $Arguments -Wait
		}
		else
		{
			# The "Pin" verb is not available on the control.exe file so the shortcut has to be created
			# Глагол "Закрепить на начальном экране" недоступен для control.exe, поэтому необходимо создать ярлык
			$Shell = New-Object -ComObject Wscript.Shell
			$Shortcut = $Shell.CreateShortcut("$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk")
			$Shortcut.TargetPath = "$env:SystemRoot\System32\control.exe"
			$Shortcut.Save()

			$Arguments = @"
	"$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk" "51201"
"@
			Start-Process -FilePath $PSScriptRoot\syspin.exe -WindowStyle Hidden -ArgumentList $Arguments -Wait
			Remove-Item -Path "$env:SystemRoot\System32\$ControlPanelLocalizedName.lnk" -Force
		}

		# Restart the Start menu
		# Перезапустить меню "Пуск"
		Stop-Process -Name StartMenuExperienceHost -Force -ErrorAction Ignore
	}
}
