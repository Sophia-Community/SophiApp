﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Change Windows feedback frequency to "Never" for the current user
# Изменить частоту формирования отзывов на "Никогда" для текущего пользователя
if ($Off.IsPresent)
{
	if (-not (Test-Path -Path HKCU:\Software\Microsoft\Siuf\Rules))
	{
		New-Item -Path HKCU:\Software\Microsoft\Siuf\Rules -Force
	}
	New-ItemProperty -Path HKCU:\Software\Microsoft\Siuf\Rules -Name NumberOfSIUFInPeriod -PropertyType DWord -Value 0 -Force
}

# Change Windows Feedback frequency to "Automatically" for the current user
# Изменить частоту формирования отзывов на "Автоматически" для текущего пользователя
if ($On.IsPresent)
{
	Remove-Item -Path HKCU:\Software\Microsoft\Siuf\Rules -Force
}
