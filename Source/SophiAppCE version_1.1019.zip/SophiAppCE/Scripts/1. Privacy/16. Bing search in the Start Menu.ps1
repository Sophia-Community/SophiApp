﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Disable Bing search in the Start Menu
# Отключить в меню "Пуск" поиск через Bing
if ($Off.IsPresent)
{
	if ((Get-WinHomeLocation).GeoId -eq 244)
	{
		if (-not (Test-Path HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer))
		{
			New-Item -Path HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Force
		}
		New-ItemProperty -Path HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name DisableSearchBoxSuggestions -PropertyType DWord -Value 1 -Force
	}
}

# Enable Bing search in the Start Menu
# Включить в меню "Пуск" поиск через Bing
if ($On.IsPresent)
{
	if ((Get-WinHomeLocation).GeoId -eq 244)
	{
		Remove-ItemProperty -Path HKCU:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name DisableSearchBoxSuggestions -Force
	}
}
