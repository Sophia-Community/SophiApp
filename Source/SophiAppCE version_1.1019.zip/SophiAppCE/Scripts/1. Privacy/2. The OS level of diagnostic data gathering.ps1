﻿param
(
	[Parameter()]
	[switch]
	$Enterprise,

	[Parameter()]
	[switch]
	$NotEnterprise,

	[Parameter()]
	[switch]
	$Default
)

# Set the OS level of diagnostic data gathering to minimum
# Установить уровень сбора диагностических сведений ОС на минимальный
if ($Enterprise.IsPresent)
{
	if (Get-WindowsEdition -Online | Where-Object -FilterScript {$_.Edition -like "Enterprise*" -or $_.Edition -eq "Education"})
	{
		# "Security"
		# "Безопасность"
		New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 0 -Force
	}
}
if ($NotEnterprise.IsPresent)
{
	if (Get-WindowsEdition -Online | Where-Object -FilterScript {$_.Edition -notlike "Enterprise*" -or $_.Edition -ne "Education"})
	{
		# "Basic"
		# "Базовая настройка"
		New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 1 -Force
	}
}

# Set the default OS level of diagnostic data gathering
# Установить уровень сбора диагностических сведений ОС по умолчанию
if ($Default)
{
	# By default
	# По умолчанию
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection -Name AllowTelemetry -PropertyType DWord -Value 3 -Force
}
