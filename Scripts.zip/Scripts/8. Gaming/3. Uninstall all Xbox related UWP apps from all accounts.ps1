﻿<#
Uninstall all Xbox related UWP apps from all accounts
App packages will not be installed when new user accounts are created

Удалить все UWP-приложения, связанные с Xbox, из всех учетных записей
Приложения не будут установлены при создании новых учетных записей
#>
$XboxAppxPackages = @(
	# Xbox Identity Provider
	# Поставщик удостоверений Xbox
	"Microsoft.XboxIdentityProvider"
	# Xbox
	# Компаньон консоли Xbox
	"Microsoft.XboxApp"
	# Xbox TCUI
	"Microsoft.Xbox.TCUI"
	# Xbox Speech To Text Overlay
	"Microsoft.XboxSpeechToTextOverlay"
	# Xbox Game Bar
	"Microsoft.XboxGamingOverlay"
	# Xbox Game Bar Plugin
	"Microsoft.XboxGameOverlay"
)
$OFS = "|"
Get-AppxPackage -PackageTypeFilter Bundle -AllUsers | Where-Object -FilterScript {$_.Name -cmatch $XboxAppxPackages} | Remove-AppxPackage -AllUsers -Verbose
$OFS = " "