﻿# Delete files in recycle bin if they have been there for over 30 days
# Удалять файлы из корзины, если они находятся в корзине более 30 дней
New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy -Name 256 -PropertyType DWord -Value 30 -Force