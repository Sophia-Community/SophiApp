﻿# Turn on network discovery and file and printers sharing if device is not domain-joined
# Включить сетевое обнаружение и общий доступ к файлам и принтерам, если устройство не присоединенно к домену
if ((Get-NetConnectionProfile).NetworkCategory -ne "DomainAuthenticated")
{
	Get-NetFirewallRule -Group "@FirewallAPI.dll,-32752", "@FirewallAPI.dll,-28502" | Set-NetFirewallRule -Profile Private -Enabled True
	Set-NetConnectionProfile -NetworkCategory Private
}