﻿# Turn off automatic installing suggested apps
# Windows silently automatically downloads and installs suggested apps from the Microsoft Store without any confirmation by default
# Отключить автоматическую установку рекомендованных приложений
# По умолчанию Windows в тихом режиме и без подтверждения автоматически скачивает и устанавливает рекомендованные приложения из Microsoft Store
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SilentInstalledAppsEnabled -PropertyType DWord -Value 0 -Force
}

if ($On.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager -Name SilentInstalledAppsEnabled -PropertyType DWord -Value 1 -Force
}