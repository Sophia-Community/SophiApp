﻿# Do not show recently added apps in Start menu
# Не показывать недавно добавленные приложения в меню "Пуск"
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	if (-not (Test-Path -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer))
	{
		New-Item -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Force
	}
	New-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name HideRecentlyAddedApps -PropertyType DWord -Value 1 -Force
}

if ($On.IsPresent)
{
	Remove-ItemProperty -Path HKLM:\SOFTWARE\Policies\Microsoft\Windows\Explorer -Name HideRecentlyAddedApps -Force
}