﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Disable the "Connected User Experiences and Telemetry" service (DiagTrack)
# Отключить службу "Функциональные возможности для подключенных пользователей и телеметрия" (DiagTrack)
if ($Off.IsPresent)
{
	Get-Service -Name DiagTrack | Stop-Service -Force
	Get-Service -Name DiagTrack | Set-Service -StartupType Disabled
}

# Enable the "Connected User Experiences and Telemetry" service (DiagTrack)
# Включить службу "Функциональные возможности для подключенных пользователей и телеметрия" (DiagTrack)
if ($On.IsPresent)
{
	Get-Service -Name DiagTrack | Set-Service -StartupType Automatic
	Get-Service -Name DiagTrack | Start-Service
}
