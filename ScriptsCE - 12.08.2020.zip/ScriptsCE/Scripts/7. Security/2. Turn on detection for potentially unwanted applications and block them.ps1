﻿# Turn on detection for potentially unwanted applications
# Включить обнаружение потенциально нежелательных приложений
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	Set-MpPreference -PUAProtection Disabled
}

if ($On.IsPresent)
{
	Set-MpPreference -PUAProtection Enabled
}