﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Disable Windows 260 character path limit
# Отключить ограничение Windows на 260 символов в пути
if ($Off.IsPresent)
{
	New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem -Name LongPathsEnabled -PropertyType DWord -Value 0 -Force
}

# Enable Windows 260 character path limit
# Включить ограничение Windows на 260 символов в пути
if ($On.IsPresent)
{
	New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem -Name LongPathsEnabled -PropertyType DWord -Value 1 -Force
}
