﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Turn on reserved storage
# Включить зарезервированное хранилище
if ($On.IsPresent)
{
	Set-WindowsReservedStorageState -State Enabled
}

# Turn off and delete reserved storage after the next update installation
# Отключить и удалить зарезервированное хранилище после следующей установки обновлений
if ($Off.IsPresent)
{
	Set-WindowsReservedStorageState -State Disabled
}
