﻿param
(
	[Parameter()]
	[switch]
	$Off
)

# Disable certain Feature On Demand v2 (FODv2) capabilities
# Отключить определенные компоненты "Функции по требованию" (FODv2)
if ($Off.IsPresent)
{
	Add-Type -AssemblyName PresentationCore, PresentationFramework

	#region Variables
	# Initialize an array list to store the FODv2 items to remove
	# Создать массив имен дополнительных компонентов для удаления
	$Capabilities = New-Object -TypeName System.Collections.ArrayList($null)

	# The following FODv2 items will have their checkboxes checked, recommending the user to remove them
	# Следующие дополнительные компоненты будут иметь чекбоксы отмеченными. Рекомендуются к удалению
	$CheckedCapabilities = @(
		# Steps Recorder
		# Средство записи действий
		"App.StepsRecorder*",

		# Microsoft Quick Assist
		# Быстрая поддержка (Майкрософт)
		"App.Support.QuickAssist*",

		# Windows Media Player
		# Проигрыватель Windows Media
		"Media.WindowsMediaPlayer*",

		# Microsoft Paint
		"Microsoft.Windows.MSPaint*",

		# WordPad
		"Microsoft.Windows.WordPad*",

		# Integrated faxing and scanning application for Windows
		# Факсы и сканирование Windows
		"Print.Fax.Scan*"
	)
	# If device is not a laptop disable "Hello.Face*" too
	# Если устройство не является ноутбуком, отключить также и "Hello.Face"
	if ((Get-CimInstance -ClassName Win32_ComputerSystem).PCSystemType -ne 2)
	{
		# Windows Hello Face
		# Распознавание лиц Windows Hello
		$CheckedCapabilities += "Hello.Face*"
	}

	# The following FODv2 items will be shown, but their checkboxes would be clear
	# Следующие дополнительные компоненты будут видны, но их чекбоксы не будут отмечены
	$ExcludedCapabilities = @(
		# The DirectX Database to configure and optimize apps when multiple Graphics Adapters are present
		# База данных DirectX для настройки и оптимизации приложений при наличии нескольких графических адаптеров
		"DirectX\.Configuration\.Database",

		# Language components
		# Языковые компоненты
		"Language\.",

		# Notepad
		# Блокнот
		"Microsoft.Windows.Notepad*",

		# Mail, contacts, and calendar sync component
		# Компонент синхронизации почты, контактов и календаря
		"OneCoreUAP\.OneSync",

		# Management of printers, printer drivers, and printer servers
		# Управление принтерами, драйверами принтеров и принт-серверами
		"Print\.Management\.Console",

		# Features critical to Windows functionality
		# Компоненты, критичные для работоспособности Windows
		"Windows\.Client\.ShellComponents"
	)
	#endregion Variables

	#region XAML Markup
	# The section defines the design of the upcoming dialog box
	# Раздел, определяющий форму диалогового окна
	[xml]$XAML = '
	<Window
		xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
		xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
		Name="Window"
		MinHeight="450" MinWidth="400"
		SizeToContent="Width" WindowStartupLocation="CenterScreen"
		TextOptions.TextFormattingMode="Display" SnapsToDevicePixels="True"
		FontFamily="Segoe UI" FontSize="12" ShowInTaskbar="False">
		<Window.Resources>
			<Style TargetType="StackPanel">
				<Setter Property="Orientation" Value="Horizontal"/>
			</Style>
			<Style TargetType="CheckBox">
				<Setter Property="Margin" Value="10, 10, 5, 10"/>
				<Setter Property="IsChecked" Value="True"/>
			</Style>
			<Style TargetType="TextBlock">
				<Setter Property="Margin" Value="5, 10, 10, 10"/>
			</Style>
			<Style TargetType="Button">
				<Setter Property="Margin" Value="20"/>
				<Setter Property="Padding" Value="10"/>
			</Style>
		</Window.Resources>
		<Grid>
			<Grid.RowDefinitions>
				<RowDefinition Height="*"/>
				<RowDefinition Height="Auto"/>
			</Grid.RowDefinitions>
			<ScrollViewer Name="Scroll" Grid.Row="0"
				HorizontalScrollBarVisibility="Disabled"
				VerticalScrollBarVisibility="Auto">
				<StackPanel Name="PanelContainer" Orientation="Vertical"/>
			</ScrollViewer>
			<Button Name="Button" Grid.Row="1"/>
		</Grid>
	</Window>
	'
	#endregion XAML Markup

	$Reader = (New-Object -TypeName System.Xml.XmlNodeReader -ArgumentList $XAML)
	$Form = [Windows.Markup.XamlReader]::Load($Reader)
	$XAML.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]") | ForEach-Object -Process {
		Set-Variable -Name ($_.Name) -Value $Form.FindName($_.Name) -Scope Global
	}

	#region Functions
	function Get-CheckboxClicked
	{
		[CmdletBinding()]
		param
		(
			[Parameter(
				Mandatory = $true,
				ValueFromPipeline = $true
			)]
			[ValidateNotNull()]
			$CheckBox
		)

		$Capability = $CheckBox.Parent.Children[1].Text
		if ($CheckBox.IsChecked)
		{
			[void]$Capabilities.Add($Capability)
		}
		else
		{
			[void]$Capabilities.Remove($Capability)
		}
		if ($Capabilities.Count -gt 0)
		{
			$Button.IsEnabled = $true
		}
		else
		{
			$Button.IsEnabled = $false
		}
	}

	function DeleteButton
	{
		[void]$Window.Close()
		$OFS = "|"
		Get-WindowsCapability -Online | Where-Object -FilterScript {$_.Name -cmatch $Capabilities} | Remove-WindowsCapability -Online
		$OFS = " "
	}

	function Add-CapabilityControl
	{
		[CmdletBinding()]
		param
		(
			[Parameter(
				Mandatory = $true,
				ValueFromPipeline = $true
			)]
			[ValidateNotNull()]
			[string]
			$Capability
		)

		$CheckBox = New-Object -TypeName System.Windows.Controls.CheckBox
		$CheckBox.Add_Click({Get-CheckboxClicked -CheckBox $_.Source})

		$TextBlock = New-Object -TypeName System.Windows.Controls.TextBlock
		$TextBlock.Text = $Capability

		$StackPanel = New-Object -TypeName System.Windows.Controls.StackPanel
		[void]$StackPanel.Children.Add($CheckBox)
		[void]$StackPanel.Children.Add($TextBlock)

		[void]$PanelContainer.Children.Add($StackPanel)

		$CheckBox.IsChecked = $false

		if ($CheckedCapabilities | Where-Object -FilterScript {$Capability -like $_})
		{
			$CheckBox.IsChecked = $true
			# If capability checked, add to the array list to remove
			# Если пакет выделен, то добавить в массив для удаления
			[void]$Capabilities.Add($Capability)
		}
	}
	#endregion Functions

	#region Events Handlers
	# Window Loaded Event
	$Window.Add_Loaded({
		$OFS = "|"
		(Get-WindowsCapability -Online | Where-Object -FilterScript {($_.State -eq "Installed") -and ($_.Name -cnotmatch $ExcludedCapabilities)}).Name | ForEach-Object -Process {
			Add-CapabilityControl -Capability $_
		}
		$OFS = " "

		if ($RU)
		{
			$Window.Title = "Удалить дополнительные компоненты"
			$Button.Content = "Удалить"
		}
		else
		{
			$Window.Title = "Optional features (FODv2) to remove"
			$Button.Content = "Uninstall"
		}
	})

	# Button Click Event
	$Button.Add_Click({DeleteButton})
	#endregion Events Handlers

	if (Get-WindowsCapability -Online | Where-Object -FilterScript {($_.State -eq "Installed") -and ($_.Name -cnotmatch ($ExcludedCapabilities -join "|"))})
	{
		if ($RU)
		{
			Write-Verbose -Message "Диалоговое окно открывается..." -Verbose
		}
		else
		{
			Write-Verbose -Message "Displaying the dialog box..." -Verbose
		}
		# Display form
		# Отобразить форму
		$Form.ShowDialog() | Out-Null
	}
	else
	{
		if ($RU)
		{
			Write-Verbose -Message "Отсутствуют данные" -Verbose
		}
		else
		{
			Write-Verbose -Message "Nothing to display" -Verbose
		}
	}
}
