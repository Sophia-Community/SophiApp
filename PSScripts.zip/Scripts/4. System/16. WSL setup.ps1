﻿param
(
	[Parameter()]
	[switch]
	$On
)

# Setup WSL
# Настроить WSL
# https://github.com/microsoft/WSL/issues/5437
if ($On.IsPresent)
{
	if (Get-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux)
	{
		# Set WSL 2 as your default version. Run the command only after restart
		# Установить WSL 2 как версию по умолчанию. Выполните команду только после перезагрузки
		wsl --set-default-version 2

		# Configuring .wslconfig
		# Настраиваем .wslconfig
		if (-not (Test-Path -Path "$env:HOMEPATH\.wslconfig"))
		{
			$wslconfig = @"
[wsl2]
swap=0
"@
			# Saving .wslconfig in UTF-8 encoding
			# Сохраняем .wslconfig в кодировке UTF-8
			Set-Content -Path "$env:HOMEPATH\.wslconfig" -Value (New-Object System.Text.UTF8Encoding).GetBytes($wslconfig) -Encoding Byte -Force
		}
		else
		{
			$String = Get-Content -Path "$env:HOMEPATH\.wslconfig" | Select-String -Pattern "swap=" -SimpleMatch
			if ($String)
			{
				(Get-Content -Path "$env:HOMEPATH\.wslconfig").Replace("swap=1", "swap=0") | Set-Content -Path "$env:HOMEPATH\.wslconfig" -Force
			}
			else
			{
				Add-Content -Path "$env:HOMEPATH\.wslconfig" -Value "`r`nswap=0" -Force
			}
		}
	}
}
