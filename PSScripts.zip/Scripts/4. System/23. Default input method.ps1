﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Set the default input method to the English language
# Установить метод ввода по умолчанию на английский язык
if ($On.IsPresent)
{
	Set-WinDefaultInputMethodOverride -InputTip "0409:00000409"
}

# Reset the default input method
# Сбросить метод ввода по умолчанию
if ($Off.IsPresent)
{
	Remove-ItemProperty -Path "HKCU:\Control Panel\International\User Profile" -Name InputMethodOverride -Force
}
