﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Do not display the Stop error information on the BSoD
# Не отображать Stop-ошибку при появлении BSoD
if ($Off.IsPresent)
{
	New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl -Name DisplayParameters -PropertyType DWord -Value 0 -Force
}

# Display the Stop error information on the BSoD
# Отображать Stop-ошибку при появлении BSoD
if ($On.IsPresent)
{
	New-ItemProperty -Path HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl -Name DisplayParameters -PropertyType DWord -Value 1 -Force
}
