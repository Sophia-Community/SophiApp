﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Change %TEMP% environment variable path to the %LOCALAPPDATA%\Temp (default) (both machine-wide, and for the current user)
# Изменить путь переменной среды для %TEMP% на LOCALAPPDATA%\Temp (значение по умолчанию) (для всех пользователей)
if ($Off.IsPresent)
{
	if (-not (Test-Path -Path $env:SystemRoot\Temp))
	{
		New-Item -Path $env:SystemRoot\Temp
	}
	if (-not (Test-Path -Path $env:LOCALAPPDATA\Temp))
	{
		New-Item -Path $env:LOCALAPPDATA\Temp -ItemType Directory -Force
	}

	[Environment]::SetEnvironmentVariable("TMP", "$env:LOCALAPPDATA\Temp", "User")
	[Environment]::SetEnvironmentVariable("TMP", "$env:SystemRoot\TEMP", "Machine")
	[Environment]::SetEnvironmentVariable("TMP", "$env:LOCALAPPDATA\Temp", "Process")
	New-ItemProperty -Path HKCU:\Environment -Name TMP -PropertyType ExpandString -Value %LOCALAPPDATA%\Temp -Force

	[Environment]::SetEnvironmentVariable("TEMP", "$env:LOCALAPPDATA\Temp", "User")
	[Environment]::SetEnvironmentVariable("TEMP", "$env:SystemRoot\TEMP", "Machine")
	[Environment]::SetEnvironmentVariable("TEMP", "$env:LOCALAPPDATA\Temp", "Process")
	New-ItemProperty -Path HKCU:\Environment -Name TEMP -PropertyType ExpandString -Value %LOCALAPPDATA%\Temp -Force

	New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name TMP -PropertyType ExpandString -Value %SystemRoot%\TEMP -Force
	New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name TEMP -PropertyType ExpandString -Value %SystemRoot%\TEMP -Force

	# Restart the Printer Spooler service (Spooler)
	# Перезапустить службу "Диспетчер печати" (Spooler)
	Restart-Service -Name Spooler -Force

	Stop-Process -Name OneDrive -Force -ErrorAction Ignore
	Stop-Process -Name FileCoAuth -Force -ErrorAction Ignore

	Remove-Item -Path $env:SystemDrive\Temp -Recurse -Force -ErrorAction Ignore

	# Remove a symbolic link to the %SystemDrive%\Temp folder
	# Удалить символическую ссылку к папке %SystemDrive%\Temp
	(Get-Item -Path $env:LOCALAPPDATA\Temp -Force).Delete()
}

# Change the %TEMP% environment variable path to the %SystemDrive%\Temp (both machine-wide, and for the current user)
# Изменить путь переменной среды для %TEMP% на %SystemDrive%\Temp (для всех пользователей)
if ($On.IsPresent)
{
	if (-not (Test-Path -Path $env:SystemDrive\Temp))
	{
		New-Item -Path $env:SystemDrive\Temp -ItemType Directory -Force
	}

	[Environment]::SetEnvironmentVariable("TMP", "$env:SystemDrive\Temp", "User")
	[Environment]::SetEnvironmentVariable("TMP", "$env:SystemDrive\Temp", "Machine")
	[Environment]::SetEnvironmentVariable("TMP", "$env:SystemDrive\Temp", "Process")
	New-ItemProperty -Path HKCU:\Environment -Name TMP -PropertyType ExpandString -Value %SystemDrive%\Temp -Force

	[Environment]::SetEnvironmentVariable("TEMP", "$env:SystemDrive\Temp", "User")
	[Environment]::SetEnvironmentVariable("TEMP", "$env:SystemDrive\Temp", "Machine")
	[Environment]::SetEnvironmentVariable("TEMP", "$env:SystemDrive\Temp", "Process")
	New-ItemProperty -Path HKCU:\Environment -Name TEMP -PropertyType ExpandString -Value %SystemDrive%\Temp -Force

	New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name TMP -PropertyType ExpandString -Value %SystemDrive%\Temp -Force
	New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" -Name TEMP -PropertyType ExpandString -Value %SystemDrive%\Temp -Force

	# Restart the Printer Spooler service (Spooler)
	# Перезапустить службу "Диспетчер печати" (Spooler)
	Restart-Service -Name Spooler -Force

	Stop-Process -Name OneDrive -Force -ErrorAction Ignore
	Stop-Process -Name FileCoAuth -Force -ErrorAction Ignore

	Remove-Item -Path $env:SystemRoot\Temp -Recurse -Force -ErrorAction Ignore
	Remove-Item -Path $env:LOCALAPPDATA\Temp -Recurse -Force -ErrorAction Ignore

	# Create a symbolic link to the %SystemDrive%\Temp folder
	# Создать символическую ссылку к папке %SystemDrive%\Temp
	New-Item -Path $env:LOCALAPPDATA\Temp -ItemType SymbolicLink -Value $env:SystemDrive\Temp -Force
}
