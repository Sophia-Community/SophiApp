﻿param
(
	[Parameter()]
	[switch]
	$Light,

	[Parameter()]
	[switch]
	$Dark
)

# Set the Windows mode color scheme to the light (current user only)
# Установить цвет режима для Windows по умолчанию на светлый (только для текущего пользователя)
if ($Light.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 1 -Force
}

# Set the Windows mode color scheme to the dark (current user only)
# Установить цвет режима для Windows по умолчанию на темный (только для текущего пользователя)
if ($Dark.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name SystemUsesLightTheme -PropertyType DWord -Value 0 -Force
}
