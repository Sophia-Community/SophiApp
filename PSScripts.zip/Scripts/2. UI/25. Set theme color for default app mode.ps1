﻿# Set light theme color for default app mode
# Установить режим приложений по умолчанию светлый
param
(
	[Parameter()]
	[switch]
	$Light,

	[Parameter()]
	[switch]
	$Dark
)

if ($Light.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 1 -Force
}

if ($Dark.IsPresent)
{
	New-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize -Name AppsUseLightTheme -PropertyType DWord -Value 0 -Force
}