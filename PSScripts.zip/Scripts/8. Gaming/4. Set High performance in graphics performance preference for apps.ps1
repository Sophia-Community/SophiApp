﻿# Set "High performance" in graphics performance preference for apps
# Установить параметры производительности графики для отдельных приложений на "Высокая производительность"
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	
}

if ($On.IsPresent)
{
	Start-Process -FilePath ms-settings:display-advancedgraphics
}