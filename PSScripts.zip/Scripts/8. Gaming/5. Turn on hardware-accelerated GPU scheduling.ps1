﻿<#
Turn on hardware-accelerated GPU scheduling. Restart needed
Determining whether the PC has a dedicated GPU to use this feature

Включить планирование графического процессора с аппаратным ускорением. Необходима перезагрузка
Определяем, имеется ли у ПК внешняя видеокарта для использования данной функции
#>
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	Remove-ItemProperty ###
}

if ($On.IsPresent)
{
	if ((Get-CimInstance -ClassName CIM_VideoController | Where-Object -FilterScript {$_.AdapterDACType -ne "Internal"}))
	{
		# Determining whether an OS is not installed on a virtual machine
		# Проверяем, не установлена ли ОС на виртуальной машине
		if ((Get-CimInstance -ClassName CIM_ComputerSystem).Model -notmatch "Virtual")
		{
			# Checking whether a WDDM verion is 2.7 or higher
			# Проверка: имеет ли WDDM версию 2.7 или выше
			$WddmVersion_Min = Get-ItemPropertyValue -Path HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers\FeatureSetUsage -Name WddmVersion_Min
			if ($WddmVersion_Min -ge 2700)
			{
				New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" -Name HwSchMode -PropertyType DWord -Value 2 -Force
			}
		}
	}
}