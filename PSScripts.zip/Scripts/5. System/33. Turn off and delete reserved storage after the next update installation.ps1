﻿# Turn off and delete reserved storage after the next update installation
# Отключить и удалить зарезервированное хранилище после следующей установки обновлений
Set-WindowsReservedStorageState -State Disabled