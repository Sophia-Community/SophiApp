﻿# Uninstall OneDrive
# Удалить OneDrive
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	[string]$UninstallString = Get-Package -Name "Microsoft OneDrive" -ErrorAction Ignore | ForEach-Object -Process {$_.Meta.Attributes["UninstallString"]}
	if ($UninstallString)
	{
		if ($RU)
		{
			Write-Verbose -Message "Удаление OneDrive" -Verbose
		}
		else
		{
			Write-Verbose -Message "Uninstalling OneDrive" -Verbose
		}
		Stop-Process -Name OneDrive -Force -ErrorAction Ignore
		Stop-Process -Name FileCoAuth -Force -ErrorAction Ignore

		# Save all opened folders in order to restore them after File Explorer restarting
		# Сохранить все открытые папки, чтобы восстановить их после перезапуска проводника
		Clear-Variable -Name OpenedFolders -Force -ErrorAction Ignore
		$OpenedFolders = {(New-Object -ComObject Shell.Application).Windows() | ForEach-Object -Process {$_.Document.Folder.Self.Path}}.Invoke()

		# Getting link to the OneDriveSetup.exe and its' argument(s)
		# Получаем ссылку на OneDriveSetup.exe и его аргумент(ы)
		[string[]]$OneDriveSetup = ($UninstallString -Replace("\s*/",",/")).Split(",").Trim()
		if ($OneDriveSetup.Count -eq 2)
		{
			Start-Process -FilePath $OneDriveSetup[0] -ArgumentList $OneDriveSetup[1..1] -Wait
		}
		else
		{
			Start-Process -FilePath $OneDriveSetup[0] -ArgumentList $OneDriveSetup[1..2] -Wait
		}
		Stop-Process -Name explorer -Force

		# Restoring closed folders
		# Восстановляем закрытые папки
		foreach ($OpenedFolder in $OpenedFolders)
		{
			if (Test-Path -Path $OpenedFolder)
			{
				Invoke-Item -Path $OpenedFolder
			}
		}

		# Getting the OneDrive user folder path
		# Получаем путь до папки пользователя OneDrive
		$OneDriveUserFolder = Get-ItemPropertyValue -Path HKCU:\Environment -Name OneDrive
		if ((Get-ChildItem -Path $OneDriveUserFolder | Measure-Object).Count -eq 0)
		{
			Remove-Item -Path $OneDriveUserFolder -Recurse -Force
		}
		else
		{
			if ($RU)
			{
				Write-Error -Message "Папка $OneDriveUserFolder не пуста. Удалите ее вручную" -ErrorAction SilentlyContinue
			}
			else
			{
				Write-Error -Message "The $OneDriveUserFolder folder is not empty. Delete it manually" -ErrorAction SilentlyContinue
			}
			Invoke-Item -Path $OneDriveUserFolder
		}

		Remove-ItemProperty -Path HKCU:\Environment -Name OneDrive, OneDriveConsumer -Force -ErrorAction Ignore
		Remove-Item -Path HKCU:\Software\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path HKLM:\SOFTWARE\WOW6432Node\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path "$env:ProgramData\Microsoft OneDrive" -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path $env:SystemDrive\OneDriveTemp -Recurse -Force -ErrorAction Ignore
		Unregister-ScheduledTask -TaskName *OneDrive* -Confirm:$false

		# Getting the OneDrive folder path
		# Получаем путь до папки OneDrive
		$OneDriveFolder = Split-Path -Path (Split-Path -Path $OneDriveSetup[0] -Parent)
		# Waiting for the FileSyncShell64.dll to be unloaded, using System.IO.File class
		# Ожидаем, пока FileSyncShell64.dll выгрузится, используя класс System.IO.File
		$FileSyncShell64dllFolder = Get-ChildItem -Path "$OneDriveFolder\*\amd64\FileSyncShell64.dll" -Force
		foreach ($FileSyncShell64dll in $FileSyncShell64dllFolder)
		{
			do
			{
				try
				{
					$FileStream = [System.IO.File]::Open($FileSyncShell64dll.FullName,"Open","Write")
					$FileStream.Close()
					$FileStream.Dispose()
					$Locked = $false
				}
				catch [System.UnauthorizedAccessException]
				{
					$Locked = $true
				}
				catch [Exception]
				{
					Start-Sleep -Milliseconds 500
					if ($RU)
					{
						Write-Verbose -Message "Ожидаем, пока $FileSyncShell64dll будет разблокирована" -Verbose
					}
					else
					{
						Write-Verbose -Message "Waiting for the $FileSyncShell64dll to be unlocked" -Verbose
					}
				}
			}
			while ($Locked)
		}

		Remove-Item -Path $OneDriveFolder -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path $env:LOCALAPPDATA\OneDrive -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path $env:LOCALAPPDATA\Microsoft\OneDrive -Recurse -Force -ErrorAction Ignore
		Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\OneDrive.lnk" -Force -ErrorAction Ignore
	}
}

if ($On.IsPresent)
{
	if (Test-Path -Path "$env:SystemRoot\SysWOW64\OneDriveSetup.exe")
	{
		Start-Process -FilePath "$env:SystemRoot\SysWOW64\OneDriveSetup.exe" -ArgumentList "/allusers"
		do
		{
			$Process = Get-Process -Name OneDriveSetup -ErrorAction Ignore
			if ($Process)
			{
				Start-Sleep -Milliseconds 500
			}
		}
		until (-not ($Process))
		Get-ScheduledTask -TaskName "Onedrive* Update*" | Start-ScheduledTask
	}
	else
	{
		try
		{
			# Downloading OneDriveSetup.exe
			# Скачиваем OneDriveSetup.exe
			[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
			if ((Invoke-WebRequest -Uri https://www.google.com -UseBasicParsing -DisableKeepAlive -Method Head).StatusDescription)
			{
				$Parameters = @{
					Uri = "https://go.microsoft.com/fwlink/p/?LinkID=2121808"
					OutFile = "$PSScriptRoot\OneDriveSetup.exe"
					Verbose = [switch]::Present
				}
				Invoke-WebRequest @Parameters
				$OneDriveSetup = $true
			}
			Start-Process -FilePath "$PSScriptRoot\OneDriveSetup.exe" -ArgumentList "/allusers"
			do
			{
				$Process = Get-Process -Name OneDriveSetup -ErrorAction Ignore
				if ($Process)
				{
					Start-Sleep -Milliseconds 500
				}
			}
			until (-not ($Process))
			Get-ScheduledTask -TaskName "Onedrive* Update*" | Start-ScheduledTask
		}
		catch
		{
			if ($Error.Exception.Status -eq "NameResolutionFailure")
			{
				if ($RU)
				{
					Write-Warning -Message "Отсутствует интернет-соединение" -ErrorAction SilentlyContinue
				}
				else
				{
					Write-Warning -Message "No Internet connection" -ErrorAction SilentlyContinue
				}
			}
		}
	}
}
