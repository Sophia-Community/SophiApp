﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Show the "Create a new video" item in the context menu
# Показывать пункт "Создать новое видео" в контекстном меню
if ($On.IsPresent)
{
	if (Get-AppxPackage -Name Microsoft.Windows.Photos)
	{
		Remove-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo -Name ProgrammaticAccessOnly -Force
	}
}

# Hide the "Create a new video" item from the context menu
# Скрыть пункт "Создать новое видео" из контекстного меню
if ($Off.IsPresent)
{
	if (Get-AppxPackage -Name Microsoft.Windows.Photos)
	{
		New-ItemProperty -Path Registry::HKEY_CLASSES_ROOT\AppX43hnxtbyyps62jhe9sqpdzxn1790zetc\Shell\ShellCreateVideo -Name ProgrammaticAccessOnly -PropertyType String -Value "" -Force
	}
}
