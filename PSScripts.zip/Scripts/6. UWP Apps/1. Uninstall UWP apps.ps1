﻿param
(
	[Parameter()]
	[switch]
	$Off
)

<#
Uninstall UWP apps
A dialog box that enables the user to select packages to remove
App packages will not be installed for new users if "Uninstall for All Users" is checked
Add UWP apps packages names to the $UncheckedAppXPackages array list by retrieving their packages names using the following command:
	(Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name

Удалить UWP-приложения
Диалоговое окно, позволяющее пользователю отметить пакеты на удаление
Приложения не будут установлены для новых пользователе, если отмечено "Удалять для всех пользователей"
Добавьте имена пакетов UWP-приложений в массив $UncheckedAppXPackages, получив названия их пакетов с помощью команды:
	(Get-AppxPackage -PackageTypeFilter Bundle -AllUsers).Name
#>
if ($Off.IsPresent)
{
	Add-Type -AssemblyName PresentationCore, PresentationFramework

	#region Variables
	# ArrayList containing the UWP apps to remove
	# Массив имен UWP-приложений для удаления
	$AppxPackages = New-Object -TypeName System.Collections.ArrayList($null)

	# List of UWP apps that won't be recommended for removal
	# UWP-приложения, которые не будут отмечены на удаление по умолчанию
	$UncheckedAppxPackages = @(
		# AMD Radeon UWP panel
		# UWP-панель AMD Radeon
		"AdvancedMicroDevicesInc*",

		# iTunes
		"AppleInc.iTunes",

		# Intel Graphics Control Center
		# UWP-панель Intel
		"AppUp.IntelGraphicsControlPanel",
		"AppUp.IntelGraphicsExperience",

		# Sticky Notes
		# Записки
		"Microsoft.MicrosoftStickyNotes",

		# Screen Sketch
		# Набросок на фрагменте экрана
		"Microsoft.ScreenSketch",

		# Photos (and Video Editor)
		# Фотографии и Видеоредактор
		"Microsoft.Windows.Photos",

		"Microsoft.Photos.MediaEngineDLC",

		# Calculator
		# Калькулятор
		"Microsoft.WindowsCalculator",

		# Xbox Identity Provider
		# Поставщик удостоверений Xbox
		"Microsoft.XboxIdentityProvider",

		# Xbox
		# Компаньон консоли Xbox
		"Microsoft.XboxApp",

		# Xbox (beta version)
		# Xbox (бета-версия)
		"Microsoft.GamingApp",
		"Microsoft.GamingServices",

		# Xbox TCUI
		"Microsoft.Xbox.TCUI",

		# Xbox Speech To Text Overlay
		"Microsoft.XboxSpeechToTextOverlay",

		# Xbox Game Bar
		"Microsoft.XboxGamingOverlay",

		# Xbox Game Bar Plugin
		"Microsoft.XboxGameOverlay",

		# NVIDIA Control Panel
		# Панель управления NVidia
		"NVIDIACorp.NVIDIAControlPanel",

		# Realtek Audio Console
		"RealtekSemiconductorCorp.RealtekAudioControl"
	)

	# UWP apps that won't be shown in the form
	# UWP-приложения, которые не будут выводиться в форме
	$ExcludedAppxPackages = @(
		# Microsoft Desktop App Installer
		"Microsoft.DesktopAppInstaller",

		# Store Experience Host
		# Узел покупок Microsoft Store
		"Microsoft.StorePurchaseApp",

		# Microsoft Store
		"Microsoft.WindowsStore",

		# Web Media Extensions
		# Расширения для интернет-мультимедиа
		"Microsoft.WebMediaExtensions"
	)
	#endregion Variables

	#region XAML Markup
	[xml]$XAML = '
	<Window
		xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
		xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
		Name="Window"
		MinHeight="450" MinWidth="400"
		SizeToContent="Width" WindowStartupLocation="CenterScreen"
		TextOptions.TextFormattingMode="Display" SnapsToDevicePixels="True"
		FontFamily="Segoe UI" FontSize="12" ShowInTaskbar="False">
		<Window.Resources>
			<Style TargetType="StackPanel">
				<Setter Property="Orientation" Value="Horizontal"/>
			</Style>
			<Style TargetType="CheckBox">
				<Setter Property="Margin" Value="10, 10, 5, 10"/>
				<Setter Property="IsChecked" Value="True"/>
			</Style>
			<Style TargetType="TextBlock">
				<Setter Property="Margin" Value="5, 10, 10, 10"/>
			</Style>
			<Style TargetType="Button">
				<Setter Property="Margin" Value="20"/>
				<Setter Property="Padding" Value="10"/>
			</Style>
		</Window.Resources>
		<Grid>
			<Grid.RowDefinitions>
				<RowDefinition Height="Auto"/>
				<RowDefinition Height="*"/>
				<RowDefinition Height="Auto"/>
			</Grid.RowDefinitions>
			<Grid Grid.Row="0">
				<Grid.ColumnDefinitions>
					<ColumnDefinition Width="*"/>
					<ColumnDefinition Width="Auto"/>
				</Grid.ColumnDefinitions>
				<StackPanel Grid.Column="1" Orientation="Horizontal">
					<CheckBox Name="CheckboxRemoveAll" IsChecked="False"/>
					<TextBlock Name="TextblockRemoveAll"/>
				</StackPanel>
			</Grid>
			<ScrollViewer Name="Scroll" Grid.Row="1"
				HorizontalScrollBarVisibility="Disabled"
				VerticalScrollBarVisibility="Auto">
				<StackPanel Name="PanelContainer" Orientation="Vertical"/>
			</ScrollViewer>
			<Button Name="Button" Grid.Row="2"/>
		</Grid>
	</Window>
	'
	#endregion XAML Markup

	$Reader = (New-Object -TypeName System.Xml.XmlNodeReader -ArgumentList $XAML)
	$Form = [Windows.Markup.XamlReader]::Load($Reader)
	$XAML.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]") | ForEach-Object -Process {
		Set-Variable -Name ($_.Name) -Value $Form.FindName($_.Name) -Scope Global
	}

	#region Functions
	function Get-CheckboxClicked
	{
		[CmdletBinding()]
		param
		(
			[Parameter(
				Mandatory = $true,
				ValueFromPipeline = $true
			)]
			[ValidateNotNull()]
			$CheckBox
		)

		$AppxName = $CheckBox.Parent.Children[1].Text
		if ($CheckBox.IsChecked)
		{
			[void]$AppxPackages.Add($AppxName)
		}
		else
		{
			[void]$AppxPackages.Remove($AppxName)
		}
		if ($AppxPackages.Count -gt 0)
		{
			$Button.IsEnabled = $true
		}
		else
		{
			$Button.IsEnabled = $false
		}
	}

	function DeleteButton
	{
		[void]$Window.Close()
		$OFS = "|"
		if ($CheckboxRemoveAll.IsChecked)
		{
			Get-AppxPackage -PackageTypeFilter Bundle -AllUsers | Where-Object -FilterScript {$_.Name -cmatch $AppxPackages} | Remove-AppxPackage -AllUsers -Verbose
		}
		else
		{
			Get-AppxPackage -PackageTypeFilter Bundle | Where-Object -FilterScript {$_.Name -cmatch $AppxPackages} | Remove-AppxPackage -Verbose
		}
		$OFS = " "
	}

	function Add-AppxControl
	{
		[CmdletBinding()]
		param
		(
			[Parameter(
				Mandatory = $true,
				ValueFromPipeline = $true
			)]
			[ValidateNotNull()]
			[string]
			$AppxName
		)

		$CheckBox = New-Object -TypeName System.Windows.Controls.CheckBox
		$CheckBox.Add_Click({Get-CheckboxClicked -CheckBox $_.Source})

		$TextBlock = New-Object -TypeName System.Windows.Controls.TextBlock
		$TextBlock.Text = $AppxName

		$StackPanel = New-Object -TypeName System.Windows.Controls.StackPanel
		[void]$StackPanel.Children.Add($CheckBox)
		[void]$StackPanel.Children.Add($TextBlock)

		[void]$PanelContainer.Children.Add($StackPanel)

		if ($UncheckedAppxPackages.Contains($AppxName))
		{
			$CheckBox.IsChecked = $false
			# Exit function, item is not checked
			# Выход из функции, если элемент не выделен
			return
		}

		# If package checked, add to the array list to uninstall
		# Если пакет выделен, то добавить в массив для удаления
		[void]$AppxPackages.Add($AppxName)
	}
	#endregion Functions

	#region Events Handlers
	# Window Loaded Event
	$Window.Add_Loaded({
		$OFS = "|"
		(Get-AppxPackage -PackageTypeFilter Bundle -AllUsers | Where-Object -FilterScript {$_.Name -cnotmatch $ExcludedAppxPackages}).Name | ForEach-Object -Process {
			Add-AppxControl -AppxName $_
		}
		$OFS = " "

		if ($RU)
		{
			$TextblockRemoveAll.Text = "Удалять для всех пользователей"
			$Window.Title = "Удалить UWP-приложения"
			$Button.Content = "Удалить"
		}
		else
		{
			$TextblockRemoveAll.Text = "Uninstall for All Users"
			$Window.Title = "UWP Packages to Uninstall"
			$Button.Content = "Uninstall"
		}
	})

	# Button Click Event
	$Button.Add_Click({DeleteButton})
	#endregion Events Handlers

	if (Get-AppxPackage -PackageTypeFilter Bundle -AllUsers | Where-Object -FilterScript {$_.Name -cnotmatch ($ExcludedAppxPackages -join "|")})
	{
		if ($RU)
		{
			Write-Verbose -Message "Диалоговое окно открывается..." -Verbose
		}
		else
		{
			Write-Verbose -Message "Displaying the dialog box..." -Verbose
		}
		# Display the dialog box
		# Отобразить диалоговое окно
		$Form.ShowDialog() | Out-Null
	}
	else
	{
		if ($RU)
		{
			Write-Verbose -Message "Отсутствуют данные" -Verbose
		}
		else
		{
			Write-Verbose -Message "Nothing to display" -Verbose
		}
	}
}
