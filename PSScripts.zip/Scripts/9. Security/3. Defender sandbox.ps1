﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Do not run Microsoft Defender within a sandbox
# Не запускать Microsoft Defender в песочнице
if ($Off.IsPresent)
{
	setx /M MP_FORCE_USE_SANDBOX 0
}

# Run Microsoft Defender within a sandbox
# Запускать Microsoft Defender в песочнице
if ($On.IsPresent)
{
	setx /M MP_FORCE_USE_SANDBOX 1
}
