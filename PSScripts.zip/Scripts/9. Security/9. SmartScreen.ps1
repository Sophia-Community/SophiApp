﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Do not check apps and files within Microsofot Defender SmartScreen
# Не проверять приложения и файлы фильтром SmartScreen в Microsoft Defender
if ($Off.IsPresent)
{
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name SmartScreenEnabled -PropertyType String -Value Off -Force
}

# Check apps and files within Microsofot Defender SmartScreen
# Проверять приложения и файлы фильтром SmartScreen в Microsoft Defender
if ($On.IsPresent)
{
	New-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer -Name SmartScreenEnabled -PropertyType String -Value Warn -Force
}
