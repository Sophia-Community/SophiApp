﻿param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

# Turn off Windows Script Host (current user only)
# Отключить Windows Script Host (только для текущего пользователя)
if ($Off.IsPresent)
{
	New-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Script Host\Settings" -Name Enabled -PropertyType DWord -Value 0 -Force
}

# Turn on Windows Script Host (current user only)
# Включить Windows Script Host (только для текущего пользователя)
if ($On.IsPresent)
{
	Remove-ItemProperty -Path "HKCU:\SOFTWARE\Microsoft\Windows Script Host\Settings" -Name Enabled -Force
}
