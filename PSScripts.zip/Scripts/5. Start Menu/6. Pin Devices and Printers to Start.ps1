﻿param
(
	[Parameter()]
	[switch]
	$On
)

# Pin the old-style "Devices and Printers" shortcut to Start
# Закрепить ярлык старого формата "Устройства и принтеры" на начальном экране
if ($On.IsPresent)
{
	if (Test-Path -Path $PSScriptRoot\syspin.exe)
	{
		$syspin = $true
	}
	else
	{
		try
		{
			# Downloading syspin.exe
			# Скачиваем syspin.exe
			# http://www.technosys.net/products/utils/pintotaskbar
			# SHA256: 6967E7A3C2251812DD6B3FA0265FB7B61AADC568F562A98C50C345908C6E827
			[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
			if ((Invoke-WebRequest -Uri https://www.google.com -UseBasicParsing -DisableKeepAlive -Method Head).StatusDescription)
			{
				$Parameters = @{
					Uri = "https://github.com/farag2/Windows-10-Setup-Script/raw/master/Start%20menu%20pinning/syspin.exe"
					OutFile = "$PSScriptRoot\syspin.exe"
					Verbose = [switch]::Present
				}
				Invoke-WebRequest @Parameters
				$syspin = $true
			}
		}
		catch
		{
			if ($Error.Exception.Status -eq "NameResolutionFailure")
			{
				if ($RU)
				{
					Write-Warning -Message "Отсутствует интернет-соединение" -ErrorAction SilentlyContinue
				}
				else
				{
					Write-Warning -Message "No Internet connection" -ErrorAction SilentlyContinue
				}
			}
		}
	}

	if ($syspin -eq $true)
	{
		$DevicesAndPrintersLocalizedName = (Get-ControlPanelItem -CanonicalName "Microsoft.DevicesAndPrinters").Name
		if ($RU)
		{
			Write-Verbose -Message "Ярлык `"$DevicesAndPrintersLocalizedName`" закрепляется на начальном экране" -Verbose
		}
		else
		{
			Write-Verbose -Message "`"$DevicesAndPrintersLocalizedName`" shortcut is being pinned to Start" -Verbose
		}
		$Shell = New-Object -ComObject Wscript.Shell
		$Shortcut = $Shell.CreateShortcut("$env:APPDATA\Microsoft\Windows\Start menu\Programs\System Tools\$DevicesAndPrintersLocalizedName.lnk")
		$Shortcut.TargetPath = "control"
		$Shortcut.Arguments = "printers"
		$Shortcut.IconLocation = "$env:SystemRoot\system32\DeviceCenter.dll"
		$Shortcut.Save()

		# Pause for 3 sec, unless the "Devices and Printers" shortcut won't displayed in the Start menu
		# Пауза на 3 с, иначе ярлык "Устройства и принтеры" не будет отображаться в меню "Пуск"
		Start-Sleep -Seconds 3
		$Arguments = @"
	"$env:APPDATA\Microsoft\Windows\Start menu\Programs\System Tools\$DevicesAndPrintersLocalizedName.lnk" "51201"
"@
		Start-Process -FilePath $PSScriptRoot\syspin.exe -WindowStyle Hidden -ArgumentList $Arguments -Wait
	}
}
