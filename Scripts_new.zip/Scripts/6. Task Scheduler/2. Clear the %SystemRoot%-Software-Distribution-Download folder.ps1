﻿<#
Create a task in the Task Scheduler to clear the %SystemRoot%\SoftwareDistribution\Download folder
The task runs on Thursdays every 4 weeks

Создать задачу в Планировщике задач по очистке папки %SystemRoot%\SoftwareDistribution\Download
Задача выполняется по четвергам каждую 4 неделю
#>
<#
Create a task in the Task Scheduler to start Windows cleaning up
The task runs every 90 days

Создать задачу в Планировщике задач по очистке обновлений Windows
Задача выполняется каждые 90 дней
#>
param
(
	[Parameter()]
	[switch]
	$Off,

	[Parameter()]
	[switch]
	$On
)

if ($Off.IsPresent)
{
	Unregister-ScheduledTask -TaskName SoftwareDistribution -Confirm:$false
}

if ($On.IsPresent)
{
	$Argument = "
		(Get-Service -Name wuauserv).WaitForStatus('Stopped', '01:00:00')
		Get-ChildItem -Path $env:SystemRoot\SoftwareDistribution\Download -Recurse -Force | Remove-Item -Recurse -Force
	"
	$Action = New-ScheduledTaskAction -Execute powershell.exe -Argument $Argument
	$Trigger = New-JobTrigger -Weekly -WeeksInterval 4 -DaysOfWeek Thursday -At 9am
	$Settings = New-ScheduledTaskSettingsSet -Compatibility Win8 -StartWhenAvailable
	$Principal = New-ScheduledTaskPrincipal -UserId "NT AUTHORITY\SYSTEM" -RunLevel Highest
	if ($RU)
	{
		$Description = "Очистка папки %SystemRoot%\SoftwareDistribution\Download"
	}
	else
	{
		$Description = "The %SystemRoot%\SoftwareDistribution\Download folder cleaning"
	}
	$Parameters = @{
		"TaskName"		= "SoftwareDistribution"
		"TaskPath"		= "Setup Script"
		"Principal"		= $Principal
		"Action"		= $Action
		"Description"	= $Description
		"Settings"		= $Settings
		"Trigger"		= $Trigger
	}
	Register-ScheduledTask @Parameters -Force
}